import * as THREE from './three.module.js';

// Create all elements of the Snow Buddy


const SnowBuddy = () => {

    //Materials
    const snowColor = new THREE.MeshPhongMaterial({
        color: 0xf0fffc});

    const carrotColor = new THREE.MeshPhongMaterial({
        color: 0xda841c});

    const hatColor = new THREE.MeshPhongMaterial({
        color: 0x5c504b});

    // const buttonColor = THREE.MeshPhongMaterial({
    //     color: 0x21180b});

    // const stickColor = THREE.MeshPhongMaterial({
    //     color: 0x724c17});

    //Snowball Parts

    let baseBall;
    baseBall = new THREE.Mesh(new THREE.SphereBufferGeometry(
        1, 30, 8), snowColor);

    let middleBall;
    middleBall = new THREE.Mesh(new THREE.SphereBufferGeometry(
        0.85, 30, 8), snowColor);

    let headBall;
    headBall = new THREE.Mesh(new THREE.SphereBufferGeometry(
        0.7, 30, 8), snowColor);



    //Carrot Nose
    //var noseSeg0 = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.05, 0.05), carrotColor);
    // var noseSeg1 = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.05, 0.05), carrotColor);
    // noseSeg1.translateZ(2);
    // var noseSeg2 = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.05, 0.05), carrotColor);
    // noseSeg2.translateZ(2);

    const nose = new THREE.Mesh(new THREE.ConeBufferGeometry(0.12, 0.16, 8), carrotColor);

    const carrotNose = new THREE.Group();
    carrotNose.add(nose);
    carrotNose.translateZ(1);
    carrotNose.translateY(-0.1);
    carrotNose.rotateX(90);



    //Eyes -- may need to change the radius

    // 1) Button Eyes
    // var leftEye = new THREE.Mesh(new (new THREE.SphereBufferGeometry(
    //     0.15, 30, 8), buttonColor));
    // //leftEye.translateX(-50);
    // var rightEye = new THREE.Mesh(new (new THREE.SphereBufferGeometry(
    //     0.15, 30, 8), buttonColor));
    // //rightEye.translateX(50);
    //
    // const buttonEyes = new THREE.Group();
    // buttonEyes.add(leftEye);
    // buttonEyes.add(rightEye);
    //buttonEyes.translateY(50);
    // buttonEyes.translateZ(115);



    //Hats

    // 1) Top Hat
    var crown = new THREE.Mesh(new THREE.CylinderBufferGeometry(0.5, 0.5, 0.7), hatColor);
    var brim = new THREE.Mesh(new THREE.CylinderBufferGeometry(0.7, 0.7, 0.1), hatColor);
    brim.translateY(-0.4);
    // var band = new THREE.Mesh(new THREE.BoxGeometry(151, 30, 151), redMat);
    // //band.translateY(-50);

    const topHat = new THREE.Group();
    topHat.add(crown);
    topHat.add(brim);
    //topHat.add(band);
    topHat.translateY(1);



    //Group head
    const headGroup = new THREE.Group();
    headGroup.add(headBall);
    headGroup.add(topHat);
    headGroup.add(carrotNose);
    //headGroup.add(buttonEyes);



    //Place Snowballs on the screen
    headGroup.position.set(0,1.2, 0);     //Where should the head be on the screen?
    middleBall.position.set(0, 0, 0);
    baseBall.position.set(0,-1.2, 0);


    //Group All components together: snowbuddyGroup
    const snowBuddyGroup = new THREE.Group();
    snowBuddyGroup.add(baseBall);
    snowBuddyGroup.add(middleBall);
    snowBuddyGroup.add(headGroup);
    scene.add(snowBuddyGroup);


    //Shadows?
    // group.traverse(function(object) {
    //     if (object instanceof THREE.Mesh) {
    //         object.castShadow = true;
    //         object.receiveShadow = true;
    //     }
    // });

}


//Build SnowBuddy
// function buildASnowbuddy() {
//     let snowBuddy;
//     snowBuddy = new SnowBuddy();
//     scene.add(snowBuddy.snowBuddyGroup);
//     snowBuddy.group.position.set(0, 0, 0);
//
//
// };

function createLighting() {
    const color = 0xFFFFFF;
    const intensity = 1;
    let directionalLight;
    directionalLight = new THREE.DirectionalLight(color, intensity);
    directionalLight.position.set(-1, 2, 4);

    const ambLight = new THREE.AmbientLight(0x474747);

    scene.add(directionalLight);
    scene.add(ambLight);
}


let scene;

//function main() {
const main = () => {

    // // CLOCK for timing functions
    // clock = new THREE.Clock(true);

    // RENDERER
    const canvas = document.getElementById("canvas");
    //document.querySelector('#canvas');   //////// is this how you get canvas?
    const renderer = new THREE.WebGLRenderer({
        canvas,
        alpha: true,
    });
    //renderer.setSize(window.innerWidth, window.innerHeight);
    //document.getElementById('canvas').appendChild(renderer.domElement);

    //});
    // renderer.setSize(window.innerWidth, window.innerHeight);
    // renderer.shadowMap.enabled = true;
    // renderer.shadowMap.soft = true;
    // document.getElementById('container').appendChild(renderer.domElement);

    // SCENE
    scene = new THREE.Scene();

    // CAMERA
    const fov = 20; //field of view (larger = fish eye)
    const aspect = 2;  // canvas default = 2 = 300/150
    const near = 0.1; //
    const far = 20; //
    const camera = new THREE.PerspectiveCamera(fov, aspect, near, far);

    camera.position.set(0, 0, 16); //move the camera a back
    //camera.position.set(500, 1000, 2000);
    //camera.lookAt(new THREE.Vector3(0, 0, 0));
    scene.add(camera);

    //createFloor();
    SnowBuddy();
    createLighting();

    renderer.render(scene, camera)

    // particles = createParticles();
    // scene.add(particles);
}

// START
main();



