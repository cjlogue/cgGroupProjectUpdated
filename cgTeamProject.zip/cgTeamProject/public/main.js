const main = () => {
    const canvas = document.getElementById("canvas");


}